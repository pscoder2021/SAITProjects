﻿/* Purpose: controller class for Main Page - Index.cshtml
 * Used by: Ind view
 * Date: 05Oct2021
 * Author: Originally written by David Grant, modified by Priya P
 * Note: Some changes has been made to this version of the code, 
 *          this will be different from the code in other members submission.
 *          All methods that uses _context is written by David Grant
 *          All comments on this code is written by Priya P
 */
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Threading.Tasks;
using Travel_Experts.Models;
using Microsoft.AspNetCore.Http;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;

namespace Travel_Experts.Controllers
{
    public class HomeController : Controller
    {
        private readonly TravelExpertsContext _context;

        public HomeController(TravelExpertsContext context)
        {
            _context = context;
        }

        // GET: Packages
        public async Task<IActionResult> Index(string location, string type)
        {
            //The code that is commented below was bringing in all the bookings for a package,
            //this is now removed and only packages with a start date of current date or later are displayed on the front page. 
            //var packages = await _context.Packages.Include(i => i.Bookings).Where(i => (i.PkgLocation != null)).ToListAsync(); 
            var packages = await _context.Packages.Where(i => (i.PkgLocation != null && i.PkgStartDate>=System.DateTime.Today)).ToListAsync();
            if (location != null)
                packages = await _context.Packages.Where(i => (i.PkgLocation == location)).ToListAsync();
            if (type != null)
                packages = await _context.Packages.Where(i => (i.PkgType == type)).ToListAsync();

            // Find packages selections
            ViewData["PkgLocation"] = new SelectList(packages, "PkgLocation", "PkgLocation");
            ViewData["PkgStartDate"] = new SelectList(_context.Packages, "PkgStartDate", "PkgStartDate");
            ViewData["PkgType"] = new SelectList(_context.Packages, "PkgType", "PkgType");
            return View(packages);           
        }

        
        //GET: Package check out, load details when clicking on the Cart Icon
        public async Task<IActionResult> CheckOut(int? id)
        {
            const decimal GST = 0.05m; //declare GST %
            if(HttpContext.Session.GetInt32("PackageId") != null) //checks if session has a packageId
            {
                id = HttpContext.Session.GetInt32("PackageId");
                var package = await _context.Packages 
                   .FirstOrDefaultAsync(m => m.PackageId == id); //gets details of package in session
                string TripTypeId = HttpContext.Session.GetString("TripType"); //gets the trip type from session
                var TripType = await _context.TripTypes.FirstOrDefaultAsync(t => t.TripTypeId == TripTypeId);
                ViewBag.TripType = TripType.Ttname; //get the trip type description from db
                int TravellerCount = (int)HttpContext.Session.GetInt32("TravelerCount"); //gets the traveller count from db.
                decimal TotalCost = package.PkgBasePrice * (decimal)TravellerCount; //calculate the cost before GST
                decimal GrandTotal = TotalCost + (TotalCost * GST); //calculate cost with GST
                ViewBag.TotalCost = TotalCost; //send total cost before GST to view
                ViewBag.GrandTotal = GrandTotal; //send grand total after GST to view
                return View(package);
            }

            TempData["message"] = $"Your cart is empty!";
            TempData["alert"] = "alert-danger";
            return RedirectToAction("Index");
        }

        [Authorize]
        //POST: make a booking for the package chosen , code written by David Grant
        //Modified to include trip type id from session - Priya P
        [HttpPost]
        public async Task<IActionResult> CheckOut([Bind("PackageId", "PkgName")] Package package)
        {
            var newBooking = new Booking(); 
            newBooking.BookingDate = System.DateTime.Now; //set booking date
            newBooking.CustomerId = HttpContext.Session.GetInt32("CustomerId"); //sets customer id from session
            newBooking.TravelerCount = (double)(HttpContext.Session.GetInt32("TravelerCount")); //sets traveller count from session
            newBooking.TripTypeId = HttpContext.Session.GetString("TripType");//sets trip type from session
            newBooking.PackageId = package.PackageId; //sets package id for the new booking

            var booking = _context.Bookings.Add(newBooking); //adds a booking to the bookings table
            await _context.SaveChangesAsync(); //save changes

            TempData["message"] = $"{package.PkgName} was successfully purchased!"; //display dismissable message to user
            TempData["alert"] = "alert-success"; //set the message color in green

            HttpContext.Session.SetInt32("PurchasedPackage", package.PackageId); //sets session variable for purchased package
            HttpContext.Session.SetInt32("Count", 0); //resets count

            return RedirectToAction("Index"); //redirect to Index page
        }




        [HttpPost]
        //POST: Find
        public IActionResult Find([Bind("PkgLocation", "PkgStartDate", "PkgType")] Package package)
        {
            string PkgLocation = package.PkgLocation;
            string PkgType = package.PkgType;
            return RedirectToAction("Index", new { location = PkgLocation, @type = PkgType });
        }

       

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
