﻿/* Purpose: controller class for displaying package details - Details.cshtml
 * Date: 05Oct2021
 * Author: David Grant, modified by Priya P
 * Note: Some changes has been made to this version of the code, 
 *          this will be different from the code in other members submission.
 *          All methods that uses _context is written by David Grant
 *          All comments on this code is written by Priya P
 */
using System;

using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Travel_Experts.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;

namespace Travel_Experts.Controllers
{
    public class PackagesController : Controller
    {
        private readonly TravelExpertsContext _context;

        public PackagesController(TravelExpertsContext context)
        {
            _context = context;
        }



        // GET: Packages for homepage cards - David Grant
        /* Date: 10-Oct-2021 
         * Original code Author: David G, modified by Priya P
         * All commented code were originally written by David Grant
         * New code written by Priya P to modify the details page content, 
         * this will be different from other members submission
         * I am bringing in the trip types from db to capture the type of trip booked. 
         * As per original code from David, this was not collected from the user nor saved.
         */

        public async Task<IActionResult> Details(int? id)
        {
            
            if (id == null)
            {
                return NotFound();
            }

            //No need to include bookings when buying a package - Priya P dt:10-Oct-2021
            //var package = await _context.Packages.Include(c => c.Bookings)//by David G
            var package = await _context.Packages.FirstOrDefaultAsync(m => m.PackageId == id);
            //Bringing in Trip types from db to show on the drop down list in Details page - Priya P dt:10-Oct-2021
            var TripType = await _context.TripTypes.OrderByDescending(t=>t.TripTypeId).ToListAsync();

            if (package == null)
            {
                return NotFound();
            }
            //   ViewData["TravelerCount"] = new SelectList(_context.Bookings, "TravelerCount", "TravelerCount");
            //   ViewBag.baseprice = ((int)package.PkgBasePrice);

            ViewBag.TripType = TripType;
            return View(package);
        }

        // POST: Package add to cart, original code by David, modified by Priya to exclude the creation of new package
        // This method will add the package Id and the no. of travellers to the Session and this will then be used to display in the cart.
        [HttpPost]
        public ActionResult Details([Bind("PackageId", "PkgName", "PkgStartDate", "PkgEndDate", "PkgBasePrice", "PkgDesc", "PkgImageLocation", "PkgLocation", "PkgType")] Package package, [Bind("TravelerCount", "TripTypeId")] Booking booking)
        {

            if (ModelState.IsValid)
            {
                TempData["message"] = $"{package.PkgName} added to cart!";
                TempData["alert"] = "alert-success";

                if (HttpContext.Session.GetInt32("Count") != null)
                    HttpContext.Session.SetInt32("Count", ((int)HttpContext.Session.GetInt32("Count") + 1));
                else
                    HttpContext.Session.SetInt32("Count", 1);

                /*---------As per David G's code, originally this method was allowing to create a new package into the Package table based on user's choice, I'm removing this idea - Priya
                **---------Web user should not be allowed to create a new record in the package table, they should only be allowed to make a booking for any available package.
                *----------This code change may be seen only in my version and not in any other's version

                              // _context.Add(package);
                             //  await _context.SaveChangesAsync();
                              // var newPackage = await _context.Packages.FirstOrDefaultAsync(m => m.PkgBasePrice == package.PkgBasePrice);

                 */
                //store PackageId and traveller count in session  - written by David Grant, comment by Priya P
                HttpContext.Session.SetInt32("PackageId", package.PackageId);
                HttpContext.Session.SetInt32("TravelerCount", (int)booking.TravelerCount);
                HttpContext.Session.SetString("TripType", booking.TripTypeId);//included by Priya P

                return RedirectToAction("Index", "Home", new { area = "" }); ;
            }

            return View("Details");
        }





    }//end class
}//end namespace
