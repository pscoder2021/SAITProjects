﻿/* Purpose: controller class for Agents
 * Used by: AgentsList view - Agents link on nav bar
 * Uses: AgentsManager
 * Date: 06Oct2021
 * Author: Priya P
 
 */
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

using Travel_Experts.Models;

namespace Travel_Experts.Controllers
{
    public class AgentsController : Controller
    {
        // GET: AgentsController - gets a list of Agents and Agencies from the db
        /// <summary>
        /// Gets a list of Agents
        /// </summary>
        /// <returns>List of agents</returns>
        public ActionResult AgentList()
        {
            List<Agent> agents = null;
            List<Agency> agencies = null;
            try
            {
                agents = AgentsManager.GetAgents();//get all agents
                agencies = AgentsManager.GetAgencies();//get all agencies
                ViewBag.Agencies = agencies;
                ViewBag.Message = "";
            }
            catch (Exception)
            {
                ViewBag.Message = "Database error getting Contact Agents data.";
            }
            return View(agents);
        }
    



    }//end class
}//end namespace
