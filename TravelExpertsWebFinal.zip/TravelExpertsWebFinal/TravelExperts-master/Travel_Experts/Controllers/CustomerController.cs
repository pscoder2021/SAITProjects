﻿/* Controller class to interact with customer profile data
 * Used by Profile, EditProfile views
 * Uses CustomerManager
 * Uses authorization
 * Author: Priya P
 * Date: 06Oct2021
 */
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Travel_Experts.Models;
using System.Linq;
using System.Threading.Tasks;

namespace Travel_Experts.Controllers
{
    [Authorize]
    public class CustomerController : Controller
    {
        // GET: CustomerController
       

        //Get profile details for the logged in customer
        public ActionResult Profile()
        {   //get customer id from session variable, stored when user logs in.
               int CustomerId = (int)HttpContext.Session.GetInt32("CustomerId");
            //int CustomerId = 119;

            try
                {   //gets customer details for the customer id in session
                    Customer customer = CustomerManager.getCustomer(CustomerId);
                    //gets all bookings for the customer id in session
                    List<Booking> bookings = CustomerManager.getCustomerBookings(CustomerId);

                    var cvm = new CustomerViewModel
                    {
                        cBookings = bookings,
                        Customer = customer,
                        ActiveCategory = "F",
                        LoadMode = "List"
                    };

                    
                    //load view 
                    return View("Profile",cvm);

                    
                }
                catch (Exception)
                {
                TempData["alert"] = "alert-danger";
                TempData["message"] = "Error loading page to show customer details.";
                    return View();
                }

            
            
        }
 
        // GET: CustomerController/Edit/5
        public ActionResult Edit()
        {
            try
            {
                int CustomerId = (int)HttpContext.Session.GetInt32("CustomerId");
                ViewBag.Action = "Edit"; //to indicate we are editing an existing recrod.
                Customer customer = CustomerManager.getCustomer(CustomerId);//gets customer details by id
                return View("EditProfile",customer); //loads editprofile page
            }
            catch
            {
                ViewBag.Message = "Error loading page to edit customer.";
                return View();
            }
        } //end get edit
    

        // POST: CustomerController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Customer customer)
        {
                if (ModelState.IsValid)
                    try
                    {
                    int CustomerId = (int)HttpContext.Session.GetInt32("CustomerId");
                    if (CustomerId == customer.CustomerId) { 
                        CustomerManager.updateCustomer(CustomerId, customer);
                        TempData["alert"] = "alert-success";
                        TempData["message"] = "Your profile is now updated";
                        
                        return RedirectToAction("Profile","Customer");//if successful go back to the list
                    }
                    else 
                        return View();

                }
                catch
                    {
                    TempData["alert"] = "alert-danger";
                    TempData["message"] = "An error has occurred when trying to save changes.";
                    return View();
                    }
                else
                    return View();
            
            
        } //end edit

    } //end class
} //end namespace
