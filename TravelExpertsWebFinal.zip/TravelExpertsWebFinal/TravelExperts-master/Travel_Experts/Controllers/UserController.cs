﻿/* Purpose: controller class for User Login/Registration and customer account creation
 * Used by: Login/Register of Index page
 * Date: 05Oct2021
 * Author: Priya P, David Grant
 * Note: Any code that uses _Context is written by David Grant, any code using Manager class is written by Priya P
 * All comments on this code is written by Priya
 */
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Collections.Generic;
using Travel_Experts.Models;
using System.Linq;

namespace Travel_Experts.Controllers
{
    public class UserController : Controller
    {

        private readonly TravelExpertsContext _context;
        //written by David G
        public UserController(TravelExpertsContext context)
        {
            _context = context;
        }
        //Written by David G - loads Login View
        public IActionResult Login()
        {
            return View("Login");
        }
        //written by David G - loads Register view
        public IActionResult Register()
        {
            return View("Register");
        }

        [HttpPost]
       /* Author: Priya.P
       ** To authenticate a user against the db table Users
       ** If user exists, their Customer Id and Email are kept in Session variables
       */
        public async Task<IActionResult> LoginAsync([Bind("Email", "Password")] User user)
        {
            User usr = UserManager.Authenticate(user.Email, user.Password); //check if user exists in db and this is the right password
            if (usr != null) //  authenticated
            {
                Customer customer = CustomerManager.getCustomerbyEmail(user.Email); //get the corresponding customer id from entered email.
                HttpContext.Session.SetInt32("CustomerId", customer.CustomerId); //stores customer id in session
                HttpContext.Session.SetString("Email", usr.Email);//stores email in session

                List<Claim> claims = new List<Claim>()
                {
                    new Claim(ClaimTypes.Email, customer.CustEmail),
                    new Claim(ClaimTypes.Surname, customer.CustLastName),
                    new Claim(ClaimTypes.GivenName, customer.CustFirstName),


                };
                ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims, "Cookies"); // authentication type: Cookies
                ClaimsPrincipal principal = new ClaimsPrincipal(claimsIdentity);

                // generate authentication cookie
                await HttpContext.SignInAsync("Cookies", principal);
                return Redirect(HttpContext.Session.GetString("Path")); //redirects user to the path that took them to login, written by David

            }
            else if (UserManager.EmailExists(user.Email) > 0)
            {
                TempData["alert"] = "alert-danger";
                TempData["message"] = "Password is incorrect!";
                return View(user); //if matching email record is found, redirect back to Login page
            }
            else
            {
                TempData["alert"] = "alert-danger";
                TempData["message"] = "Username does not exist!";
                return View(user); //if no matching record is found, redirect back to Login page
            }
        }//LoginAsync

        [HttpPost]
        /* Author: Priya.P
        ** To create a user in the db table Users
        ** If user email exists, a model error is generated, if not new record is created
        *  The new Customer Id and Email are kept in Session variables
        */
        public IActionResult Register([Bind("Email", "FirstName", "LastName", "Password", "cPassword")] UserViewModel ouserViewModel)
        {
            //written by David G, checks if the user's email exists in the table

            User check = _context.Users.FirstOrDefault(t => t.Email == ouserViewModel.Email);
            if (check != null) //adds an error to Model State to show email exists
            {
                ModelState.AddModelError("Email",
                    $"The entered email {ouserViewModel.Email} already exists.");
                return View(ouserViewModel); //redisplay the error on the registration form
            }
            //written by Priya P - create a record in the user table and then in the customer table

            if (ModelState.IsValid)
            {
                try
                {
                    User nUser = new User();//create new user object 

                    nUser.Email = ouserViewModel.Email;
                    nUser.Password = EncryptDecrypt.Encrypt(ouserViewModel.Password);//encrypts the entered password
                    nUser.RoleId = "C"; //default user role is C for web customer
                    UserManager.createUser(nUser); //created a user record
                    Customer nCustomer = new Customer(); //now create a customer record
                    nCustomer.CustFirstName = ouserViewModel.FirstName; //first name at the time of registration
                    nCustomer.CustLastName = ouserViewModel.LastName; //last name at the time of registration
                    nCustomer.CustEmail = ouserViewModel.Email; //email at the time of registration - links user and customer 
                    nCustomer.CustAddress = ""; //assign "" to all other not null columns in customer table.
                    nCustomer.CustCity = "";
                    nCustomer.CustCountry = "";
                    nCustomer.CustPostal = "";
                    nCustomer.CustBusPhone = "";
                    nCustomer.CustHomePhone = "";
                    nCustomer.CustProv = "";

                    int CustomerId = CustomerManager.addCustomer(nCustomer); //returns customer id upon creation of customer record
                    HttpContext.Session.SetInt32("CustomerId", CustomerId); //stores the newly created customer id in session to facilitate a booking
                    HttpContext.Session.SetString("Email", ouserViewModel.Email);//stores the email in session
                    return Redirect(HttpContext.Session.GetString("Path"));//returns user back to the URL they originated the registration - David G
                }
                catch 
                {
                    TempData["alert"] = "alert-danger";
                    TempData["message"] = "Unexpected error occurred when trying to create a user";
                    return View(ouserViewModel);
                }
            }
            else
                return View(ouserViewModel); //errors in the model, show the registration form back to the user.
        }

        [HttpPost]
        //Author: David Grant
        //To return client side validation error if Email exists in the db.

        public JsonResult VerifyEmail(string Email) 
        {
            if (_context.Users.Where(i => i.Email.ToLowerInvariant().Equals(Email.ToLower())) != null)
            {
                return Json("This email already exists!");
            }
            return Json(true);
        }

        //client side validation of email
        //public JsonResult VerifyEmail(string Email)
        //{
        //    bool isExist = _context.Users.Where(i => i.Email.ToLowerInvariant().Equals(Email.ToLower())) != null;

        //    return Json(!isExist, new Newtonsoft.Json.JsonSerializerSettings());
        //}

        /*
        **Author: Priya P
        **Purpose: To remove user from session and remove from Cookies
        **Resets session variables related to User
        */
        public async Task<IActionResult> LogoutAsync()
        {
            // remove the authentication cookie
            HttpContext.Session.SetInt32("Count", 0);
            await HttpContext.SignOutAsync("Cookies");//signs out the user 
            HttpContext.Session.SetString("Email", "");//removes email from session
            HttpContext.Session.SetInt32("CustomerId", 0);// no current customer
            return RedirectToAction("Index", "Home");
        }// LogoutAsync

    }//end controller
}//end namespace
