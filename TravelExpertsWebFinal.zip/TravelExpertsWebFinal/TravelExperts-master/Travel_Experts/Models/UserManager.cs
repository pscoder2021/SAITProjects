﻿/* Class to access data of users table 
 * Used in User controller
 * Uses EncryptDecrypt class to encrypt the password
 * Author: Priya P
 * Date: 05Oct2021
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Travel_Experts.Models
{
    public class UserManager
    {
        //Authenticate a user by email and password as stored in the database
        public static User Authenticate(string Email, string password)
        {
            TravelExpertsContext db = new TravelExpertsContext();
            string ePassword = EncryptDecrypt.Encrypt(password); //encrypt password
            List<User> users = db.Users.ToList();
            User user = users.SingleOrDefault(u => u.Email == Email && u.Password == ePassword);
            return user;
        }// Authenticate

        //check if the email already exists in the users table
        public static int EmailExists(string email)
        {
            int iCount = 0;
            TravelExpertsContext db = new TravelExpertsContext();
            if (!string.IsNullOrEmpty(email))
            {
                iCount = db.Users.Where(u => u.Email.ToLower() == email.ToLower()).Count();
            }
            return iCount;
        }//Email exists

        //create a new user in the user table
        public static void createUser(User user) 
        {
            TravelExpertsContext db = new TravelExpertsContext();
            db.Users.Add(user);
            db.SaveChanges();
        }//create user
       
       
    }//end class
}//end namespace
