﻿/* Class to access data of customers table 
 * Used in CustomerController, User controller
 * Author: Priya P
 * Date: 05Oct2021
 */
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

using System.Linq;
using System.Threading.Tasks;

namespace Travel_Experts.Models
{
    public class CustomerManager
    {
        //method to add a customer to the database
        /// <summary>
        /// Add a customer
        /// </summary>
        /// <param name="customer">customer object</param>
        /// <returns>customer id as int</returns>
        public static int addCustomer(Customer customer)
        {
            TravelExpertsContext db = new TravelExpertsContext();
            db.Customers.Add(customer); //adds new customer
            db.SaveChanges();
            int CustId = customer.CustomerId; //returns newly generated customer id
            return CustId; //returns customer id
        }//add customer

        public static void updateCustomer(int custId , Customer customer)
        {
            TravelExpertsContext db = new TravelExpertsContext();
            Customer oCustomer = db.Customers.Find(custId);
            if (oCustomer != null)
            {
                oCustomer.CustFirstName = customer.CustFirstName;
                oCustomer.CustLastName = customer.CustLastName;
                oCustomer.CustHomePhone = customer.CustHomePhone;
                oCustomer.CustProv = customer.CustProv;
                oCustomer.CustPostal = customer.CustPostal;
                oCustomer.CustAddress = customer.CustAddress;
                oCustomer.CustBusPhone = customer.CustBusPhone;
                oCustomer.CustCity = customer.CustCity;
                oCustomer.CustCountry = customer.CustCountry;
                db.Customers.Update(oCustomer);
                db.SaveChanges();
            }

        }

        //method to get customer details by id
        /// <summary>
        /// Get customer details by Customer Id
        /// </summary>
        /// <param name="CustId">Customer Id as int</param>
        /// <returns>Customer object</returns>
        public static Customer getCustomer(int CustId)
        {
            TravelExpertsContext db = new TravelExpertsContext();
            Customer customer = db.Customers.Find(CustId); //search for customer by Id
            return customer;
        }
        //method to get customer details by email
        /// <summary>
        /// Get customer details by email
        /// </summary>
        /// <param name="Email">Email as string</param>
        /// <returns>Customer object</returns>
        public static Customer getCustomerbyEmail(string Email)
        {
            TravelExpertsContext db = new TravelExpertsContext();
            Customer customer = db.Customers.Where(c=>c.CustEmail.ToLower()==Email.ToLower()).FirstOrDefault();//search for customer by email.
            return customer;
        }

        //method to get all bookings for a customer
        /// <summary>
        /// Get a list of bookings for the Customer Id entered 
        /// </summary>
        /// <param name="CustId">Customer Id as int</param>
        /// <returns>List of bookings</returns>
        public static List<Booking> getCustomerBookings(int CustId)
        {
            List<Booking> bookings;
            TravelExpertsContext db = new TravelExpertsContext();
            //get all bookings for a customer, including package details search by Customer Id
            bookings = db.Bookings.Include(p=>p.Package).Where(b => b.CustomerId == CustId).OrderByDescending(b=>b.BookingId).ToList();
            return bookings;
        }



    }
}
