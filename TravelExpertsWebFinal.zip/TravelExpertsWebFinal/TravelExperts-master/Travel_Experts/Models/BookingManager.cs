﻿/* Class to access data from BOOKINGS table for the logged in customer
 * Used in BookingController
  * Author: Priya P
 * Date: 06Oct2021
 */
using Microsoft.EntityFrameworkCore;
using System.Linq;


namespace Travel_Experts.Models
{
    public class BookingManager
    {
        //Get booking by booking id and customer Id
        public static Booking GetBooking(int BkgId, int CustId)
        {
           TravelExpertsContext db = new TravelExpertsContext();
            Booking booking = db.Bookings.Include(b=>b.Package).Where(b=>b.BookingId==BkgId && b.CustomerId==CustId).FirstOrDefault();
            return booking;
        }//end get booking
        
        //update a booking
        public static void updateBooking(Booking booking)
        {
            TravelExpertsContext db = new TravelExpertsContext();
            Booking oBooking = db.Bookings.Find(booking.BookingId);//find existing data based on id from new object. 
            oBooking.TravelerCount = booking.TravelerCount;//assign new data to existing object 
            db.SaveChanges();
        }//end update

        //delete a booking
        public static void delBooking(int bookingId)
        {
            TravelExpertsContext db = new TravelExpertsContext();
            Booking oBooking = db.Bookings.Find(bookingId);//find existing data based on id from new object. 
            BookingDetail bookingDetail = db.BookingDetails.Find(bookingId);
            if (bookingDetail != null)
                db.BookingDetails.Remove(bookingDetail);
            db.Bookings.Remove(oBooking);
            db.SaveChanges();
        }//end delete
    }
}
