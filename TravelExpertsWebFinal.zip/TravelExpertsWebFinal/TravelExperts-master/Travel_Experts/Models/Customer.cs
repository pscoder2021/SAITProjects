﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Travel_Experts
{
    [Index(nameof(AgentId), Name = "EmployeesCustomers")]
    public partial class Customer
    {
        public Customer()
        {
            Bookings = new HashSet<Booking>();
            CreditCards = new HashSet<CreditCard>();
            CustomersRewards = new HashSet<CustomersReward>();
        }

        [Key]
        public int CustomerId { get; set; }

        [Required(ErrorMessage = "Please enter your First Name.")]
        [StringLength(25)]
        [RegularExpression("^[a-zA-Z0-9' ]+$", ErrorMessage = "First Name may not contain special characters.")]
        [Display(Name = "First Name")]
        public string CustFirstName { get; set; }

        [Required(ErrorMessage = "Please enter your Last Name.")]
        [StringLength(25)]
        [RegularExpression("^[a-zA-Z0-9' ]+$", ErrorMessage = "Last Name may not contain special characters.")]
        [Display(Name = "Last Name")]
        public string CustLastName { get; set; }

        [Required(ErrorMessage = "Please enter your Address.")]
        [StringLength(75)]
        [Display(Name = "Address")]
        [RegularExpression("^[a-zA-Z0-9'. ]+$", ErrorMessage = "Address may not contain special characters.")]
        public string CustAddress { get; set; }

        [Required(ErrorMessage = "Please enter your City.")]
        [StringLength(50)]
        [RegularExpression("^[a-zA-Z0-9'. ]+$", ErrorMessage = "Address may not contain special characters.")]
        [Display(Name = "City")]
        public string CustCity { get; set; }

        [Required(ErrorMessage = "Please enter your Province.")]
        [StringLength(2)]
        [RegularExpression("^[a-zA-Z0-9'. ]+$", ErrorMessage = "Address may not contain special characters.")]
        [Display(Name = "Province")]
        public string CustProv { get; set; }

        [Required(ErrorMessage = "Please enter your Postal Code.")]
        [StringLength(7)]
        [RegularExpression("^[a-zA-Z0-9 ]+$", ErrorMessage = "Address may not contain special characters.")]
        [Display(Name = "Postal Code")]
        public string CustPostal { get; set; }

        [StringLength(25)]
        [Display(Name = "Country")]
        [RegularExpression("^[a-zA-Z0-9'. ]+$", ErrorMessage = "Country may not contain special characters.")]
        public string CustCountry { get; set; }

        [StringLength(20)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Phone number must be in (999)-999-9999 format.")]
        [Display(Name = "Home Phone")]
        public string CustHomePhone { get; set; }

        [Required(ErrorMessage = "Please enter your Business Phone No.")]
        [StringLength(20)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Phone number must be in (999)-999-9999 format.")]
        [Display(Name = "Business")]
        public string CustBusPhone { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Email")]
        [DataType(DataType.EmailAddress)]
        public string CustEmail { get; set; }
        public int? AgentId { get; set; }
        [ForeignKey(nameof(AgentId))]
        [InverseProperty("Customers")]
        public virtual Agent Agent { get; set; }
        [InverseProperty(nameof(Booking.Customer))]
        public virtual ICollection<Booking> Bookings { get; set; }
        [InverseProperty(nameof(CreditCard.Customer))]
        public virtual ICollection<CreditCard> CreditCards { get; set; }
        [InverseProperty(nameof(CustomersReward.Customer))]
        public virtual ICollection<CustomersReward> CustomersRewards { get; set; }
    }
}
